# dns_lb
DNS load balancer by using Cloudflare API and go-torch

Requires: 
https://github.com/TorchPing/go-torch

Based on: 
https://github.com/yulewang/cloudflare-api-v4-ddns
https://github.com/lllvcs/huaweicloud_ddns
